<?php
/**
 * User Registration
 * Creates a new user with hashed password using prepared statements.
 */

require_once(__DIR__ . '/../config/database.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $phone = htmlspecialchars(trim($_POST['phone'] ?? ''));

    // Validate inputs
    if (empty($name) || empty($email) || empty($password)) {
        die("All fields are required.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    // Check if email already exists
    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();

    if ($check->get_result()->num_rows > 0) {
        die("Email already registered.");
    }
    $check->close();

    // Hash password and insert
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (name, email, password, phone) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $hashed_password, $phone);

    if ($stmt->execute()) {
        header("Location: ../../src/pages/signup.html?success=1");
    } else {
        echo "Registration failed. Please try again.";
    }

    $stmt->close();
}

$conn->close();
?>
